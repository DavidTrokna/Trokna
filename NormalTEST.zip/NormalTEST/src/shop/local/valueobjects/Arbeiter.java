package shop.local.valueobjects;
import java.util.Scanner;

public class Arbeiter extends User {

    public Arbeiter(String name, String passwort, String nummer, String a) {

        super(name, passwort, nummer, "a");
    }
}
